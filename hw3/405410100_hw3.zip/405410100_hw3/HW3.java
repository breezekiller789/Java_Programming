//  Java程式設計作業三      資工    黃晉威  405410100

public class HW3 {
    public static void main (String[] args) {
        GUI gui = new GUI();
        gui.setVisible(true);
        gui.setSize(1920, 1080);
        gui.setDefaultCloseOperation(GUI.EXIT_ON_CLOSE);
    }
}
