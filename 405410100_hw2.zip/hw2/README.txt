1 . 編譯
    
    我有放我的Makefile，助教可以直接make，就會產生byte code，我也有寫clean，

    make clean可以把byte code刪掉。

2 . 執行
    
    java DriverCode
