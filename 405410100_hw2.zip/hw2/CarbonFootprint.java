//  CarbonFootprint的Interface
public interface CarbonFootprint{
    //  我選擇回傳整數，因為我碳足跡的單位都會轉成公克，小數點其實不會差太多，
    //  同時也方便觀看，更直覺一點。
    public int getCarbonFootprint();
}
